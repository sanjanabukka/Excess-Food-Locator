from google.cloud import vision
import pandas as pd
from google.cloud import storage
import base64
import json
import os
from google.cloud import pubsub_v1
import random

vision_client = vision.ImageAnnotatorClient()
storage_client = storage.Client()
publisher = pubsub_v1.PublisherClient()

project_id = os.environ["GCP_PROJECT"]
storage_topic_name = os.environ["STORE_DATA_TOPIC_NAME"]


def process_image(file, context):
    """Cloud Function triggered by Cloud Storage when a file is changed.
    Args:
        file (dict): Metadata of the changed file, provided by the triggering
                                 Cloud Storage event.
        context (google.cloud.functions.Context): Metadata of triggering event.
    Returns:
        None; the output is written to stdout and Stackdriver Logging
    """

    #get filename, name of object and metadata from GCS bucket
    bucket = get_storage_obj_details(file, "bucket")
    name = get_storage_obj_details(file, "name")
    metadata = get_storage_obj_details(file, "metadata")

    #call function to classify image
    classify_image(bucket, name, metadata)


'''
Function to return the details of GCS bucket Object.
Args:
    obj (file) : GCS Object file
    param(text): String represnting data to get from file
Returns: 
    specific detail/info of GCS object
'''
def get_storage_obj_details(obj, param):
    var = obj.get(param)
    if not var:
        raise ValueError(
            "{} is not provided. Make sure you have \
                          property {} in the request".format(
                param, param
            )
        )
    return var

'''
Function to classify image and create a food item message with deteails from classification and UI and push to pubsub.
Args:
    bucket  : GCS bucket
    name: File name in bucket
    metadata: GCS Object metadata
Returns: 
    None; the output is pushed to pubsub

'''
def classify_image(bucket, filename, metadata):
    futures = []

    #Call cloud vision API and pass bucket url
    image = vision.Image(
        source=vision.ImageSource(gcs_image_uri=f"gs://{bucket}/{filename}")
    )

    # Create a Pandas frame of labels received from cloud vision API
    label_detection_response = vision_client.label_detection(image=image)
    labels = label_detection_response.label_annotations
    label_df = pd.DataFrame(columns=['name', 'score'])
    for label in labels:
        label_df = label_df.append(
            dict(
                name=label.description,
                score=label.score
            ),
            ignore_index=True)
        print(label.description)

    # Create a Pandas frame of objects received from cloud vision API
    object_detection_response = vision_client.object_localization(image=image)
    objects = object_detection_response.localized_object_annotations
    object_df = pd.DataFrame(columns=['name', 'score'])
    for object in objects:
        object_df = object_df.append(
            dict(
                name=object.name,
                score=object.score
            ),
            ignore_index=True)
        print(object.name)



    # Create a combined pandas data frame containing labels and objects
    combined_df = label_df.append(object_df, ignore_index=True)

    #Get the public url of the GCS file
    read_storage_client = storage.Client()
    bucket = read_storage_client.get_bucket(bucket)
    blob = bucket.get_blob(filename)
    url = blob.public_url

    #Classify the food item based on labels and objects scores detected and assign appropriate category
    category = "default"
    if not combined_df.empty and 'Food' not in combined_df.values and 'Household supply' in combined_df.values:
        if combined_df.loc[combined_df['name'] == 'Household supply']['score'].count() and float(
                combined_df.loc[combined_df['name'] == 'Household supply']['score'].values[0]) > 0.70:
            print("category is home_supply")
            category = "house_supply"
    else:
        if not combined_df.empty and 'Dish' in combined_df.values and 'Cuisine' in combined_df.values:
            if (combined_df.loc[combined_df['name'] == 'Dish']['score'].count() and float(
                    combined_df.loc[combined_df['name'] == 'Dish']['score'].values[0]) > 0.90) or (
                    combined_df.loc[combined_df['name'] == 'Cuisine']['score'].count() and float(
                    combined_df.loc[combined_df['name'] == 'Cuisine']['score'].values[0]) > 0.90):
                print("category is cooked food")
                category = "cooked_food"
        elif not combined_df.empty and 'Produce' in combined_df.values:
            if (combined_df.loc[combined_df['name'] == 'Vegetable']['score'].count() and float(
                    combined_df.loc[combined_df['name'] == 'Vegetable']['score'].values[0]) > 0.70) or (
                    combined_df.loc[combined_df['name'] == 'Fruit']['score'].count() and float(
                    combined_df.loc[combined_df['name'] == 'Fruit']['score'].values[0]) > 0.70):
                print("category is produce")
                category = "produce"
        elif not combined_df.empty and 'Packaged goods'.lower() in (y.lower() for x in combined_df.values for y in x if type(y)==str):
            if combined_df.loc[combined_df['name'].str.lower().str.contains('Packaged goods'.lower())][
                'score'].count() and float(
                    combined_df.loc[combined_df['name'].str.lower().str.contains('Packaged goods'.lower())]['score'].values[0]) > 0.70:
                print("category is packed goods")
                category = "packed_food"
        else:
            print("category is", category)

    #Create a message to of the classified food_item along with other details received from the /DonateFood form like location, pickup time etc.
    message = {
        "food_item_id": random.randint(5000, 9000),
        "image": url,
        "title": filename,
        "lat": metadata["lat"],
        "long": metadata["long"],
        "pickup": metadata["pickuptime"],
        "description": metadata["description"],
        "category": category,
        "address": metadata["address"],
        "available": metadata["available"],
        "date": metadata["date"]
    }


    # Push message to cloud pubsub
    message_data = json.dumps(message).encode("utf-8")
    storage_topic_path = publisher.topic_path(project_id, storage_topic_name)
    future = publisher.publish(storage_topic_path, data=message_data)
    futures.append(future)
    print("successfully published")

    for future in futures:
        future.result()

